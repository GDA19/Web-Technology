function validate() {
    var userName = document.getElementById("userName");
    var userEmail = document.getElementById("userEmail");
    var userText = document.getElementById("userText");

    if(!userName.value) {
        userName.style.border = "2px solid red";
        return false;
    }

    if(!userEmail.value) {
        userEmail.style.border = "2px solid red";
        return false;
    }
    if(!userText.value) {
        userText.style.border = "2px solid red";
        return false;
    }


    return true;

}